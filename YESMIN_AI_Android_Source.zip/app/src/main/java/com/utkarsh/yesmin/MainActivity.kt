package com.utkarsh.yesmin

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { YesminApp(onSpeak = { speak(it) }) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yesmin_reply") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YesminApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf("https://YOUR_BACKEND_URL/v1/chat/completions") }
    var apiModel by remember { mutableStateOf("YOUR_MODEL") }
    var answer by remember { mutableStateOf("Hello Utkarsh! Main YESMIN hoon. Batao, aaj kya karna hai?") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf("YESMIN: Ready when you are.")) }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { input = spoken }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "YESMIN is listening...")
            }
            runCatching { speechLauncher.launch(intent) }
        }
    }

    fun openApp(query: String): Boolean {
        val pm = context.packageManager
        val apps = listOf(
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "camera" to "com.android.camera2",
            "settings" to "com.android.settings",
            "play store" to "com.android.vending"
        )
        val match = apps.firstOrNull { query.contains(it.first, true) }
        val launch = match?.let { pm.getLaunchIntentForPackage(it.second) }
        if (launch != null) { context.startActivity(launch); return true }
        return false
    }

    fun handleLocalCommand(text: String): String? {
        val q = text.lowercase(Locale.ROOT)
        if (q.contains("youtube") || q.contains("गाना") || q.contains("song")) {
            val search = Uri.encode(text.replace(Regex("(?i)(youtube|par|gana|song|chalao|play)"), "").trim())
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$search")))
            return "YouTube par search khol diya hai. Wahan se video select kar lo."
        }
        if (q.contains("chrome") || q.contains("camera") || q.contains("settings") || q.contains("play store")) {
            if (openApp(q)) return "App open kar diya."
        }
        if (q.contains("accessibility") || q.contains("screen control")) {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "Accessibility settings khol rahi hoon. YESMIN service ko tabhi enable karna jab tum screen control chahte ho."
        }
        if (q.contains("back")) { context.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); return "Home screen par aa gaye." }
        return null
    }

    suspend fun askAI(prompt: String): String = withContext(Dispatchers.IO) {
        if (endpoint.contains("YOUR_BACKEND_URL")) return@withContext "AI connect karne ke liye Settings mein apna secure backend URL set karo. Phone ke local commands abhi bhi kaam karte hain."
        val body = JSONObject().apply {
            put("model", apiModel)
            put("messages", org.json.JSONArray().put(JSONObject().put("role", "system").put("content",
                "You are YESMIN, a friendly, caring, respectful female AI assistant. Reply naturally in Hindi or Hinglish. You are an AI, not a real romantic partner. For phone actions, explain the action and ask confirmation when it could affect data or privacy."))
                .put(JSONObject().put("role", "user").put("content", prompt)))
        }.toString()
        val req = Request.Builder().url(endpoint).post(body.toRequestBody("application/json".toMediaType())).build()
        runCatching {
            OkHttpClient().newCall(req).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) error("Server error ${response.code}: $raw")
                JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }.getOrElse { "AI connection mein dikkat hai: ${it.message}. Backend URL aur server check karo." }
    }

    val bg = Brush.verticalGradient(listOf(Color(0xFF090817), Color(0xFF11152C), Color(0xFF090817)))
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB58CFF), background = Color(0xFF090817))) {
        Scaffold(containerColor = Color.Transparent, topBar = {
            TopAppBar(title = { Column { Text("YESMIN AI", fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text("Your personal assistant", fontSize = 11.sp, color = Color.LightGray) } },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF111127), titleContentColor = Color.White))
        }) { pad ->
            Column(Modifier.fillMaxSize().background(bg).padding(pad).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(12.dp))
                Box(Modifier.size(150.dp).background(Brush.radialGradient(listOf(Color(0xFF7545C7), Color(0xFF17142F), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFD8C0FF), modifier = Modifier.size(68.dp))
                }
                Text("ONLINE • READY", color = Color(0xFF9BE7D5), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1A32)), shape = RoundedCornerShape(18.dp)) {
                    Text(answer, Modifier.padding(16.dp), color = Color.White, fontSize = 16.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            }
                            runCatching { speechLauncher.launch(i) }
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text("Speak") }
                    OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Icon(Icons.Default.TouchApp, null); Text("Screen control") }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ask YESMIN anything...") }, trailingIcon = {
                        IconButton(enabled = !busy, onClick = {
                            val prompt = input.trim()
                            if (prompt.isNotEmpty()) {
                                busy = true
                                scope.launch {
                                    val local = handleLocalCommand(prompt)
                                    val reply = local ?: askAI(prompt)
                                    answer = reply; history = history + "You: $prompt" + "YESMIN: $reply"
                                    onSpeak(reply); input = ""; busy = false
                                }
                            }
                        }) { Icon(Icons.Default.Send, "Send") }
                    }, shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    QuickAction("YouTube", Icons.Default.PlayArrow) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))) }
                    QuickAction("Coding", Icons.Default.Code) { input = "Help me write an Android app" }
                    QuickAction("Settings", Icons.Default.Settings) { showSettings = true }
                }
                Spacer(Modifier.height(10.dp))
                Text(if (busy) "YESMIN is thinking..." else "Recent conversation", color = Color(0xFFB9B4D0), fontSize = 12.sp)
                LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    items(history.takeLast(8).reversed()) { Text(it, Modifier.fillMaxWidth().padding(vertical = 5.dp), color = Color(0xFFD9D5E8), fontSize = 12.sp) }
                }
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("AI Backend Settings") },
            text = { Column {
                Text("Use your own secure OpenAI-compatible backend. Do not paste a private API key into this app.")
                OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Chat Completions URL") })
                OutlinedTextField(apiModel, { apiModel = it }, label = { Text("Model name") })
            } },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Save for this session") } })
    }
}

@Composable
fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick) { Icon(icon, null); Spacer(Modifier.width(4.dp)); Text(label) }
}
