# YESMIN AI – Android starter project

यह Android Studio project YESMIN AI का पहला working starter है। इसमें Compose UI, Hindi speech input, Android Text-to-Speech, कुछ local app intents, YouTube search और OpenAI-compatible chat backend hook है।

## चलाने का तरीका
1. Android Studio में इस folder को Open Project से खोलें।
2. Gradle sync पूरा होने दें।
3. फोन/टैबलेट पर USB debugging चालू करके Run दबाएँ, या Build > Build APK(s) चुनें।
4. पहली बार microphone permission दें।
5. Screen control के लिए app के `Screen control` बटन से Android Accessibility Settings खोलें और YESMIN AI service को स्वयं enable करें।

## AI online connection
Settings में अपना HTTPS Chat Completions endpoint और model name डालें। उदाहरण endpoint आपके अपने backend का होगा:
`https://your-domain.example/v1/chat/completions`

इस starter में API key जानबूझकर app में नहीं रखी गई है। Production में अपने server पर provider API key रखें और app से अपने backend को call करें। Backend को OpenAI-compatible JSON response (`choices[0].message.content`) लौटाना होगा।

## अभी क्या काम करता है
- Hindi speech recognition (Android recognizer उपलब्ध होने पर)
- Android Text-to-Speech (फोन में installed voice पर निर्भर)
- YouTube search खोलना
- कुछ app launch intents
- AI chat backend integration point
- Accessibility service skeleton और opt-in text click/tap support

## अभी क्या अधूरा है
- Wake-word / always-listening: इस starter में शामिल नहीं; battery/privacy के लिए explicit mic button है।
- Screen tap: Accessibility service skeleton मौजूद है, लेकिन UI से arbitrary coordinate tap command अभी expose नहीं किया गया।
- API settings अभी session-only हैं; सुरक्षित persistent configuration अगली iteration में जोड़ें।
- APK इस source project से Android Studio में build होगा; इस environment में compiled APK का दावा नहीं किया जा रहा।

## Privacy & safety
Accessibility permission powerful है। केवल तभी enable करें जब आप YESMIN की screen interaction सुविधा चाहते हों। यह service screen content पढ़ने/क्लिक करने की क्षमता रख सकती है। Sensitive actions (payments, messages, deletion, account changes) पर manual confirmation रखें।
